<?php


// MACHINE LINUX 
$BDD_host="localhost";
$BDD_user="CaptainBidou";
$BDD_password="CHARLIE"; 
$BDD_base="DoremiiSafe";

?>
